<?php
	use fruithost\ModuleInterface;
	
	class Tickets extends ModuleInterface {
		public function init() {
			
		}
	}
?>