<div class="jumbotron text-center bg-transparent text-muted">
	<i class="material-icons">sentiment_very_dissatisfied</i>
	<h2>No Databases available!</h2>
	<p class="lead">Please create a new database to administer it.</p>
	<button type="button" name="create" data-toggle="modal" data-target="#create_databases" class="btn btn-lg btn-primary mt-4">Create new Database</button>
</div>