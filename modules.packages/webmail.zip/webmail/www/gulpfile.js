require('./modules/CoreWebclient/gulp-tasks/javascript.js');
require('./modules/CoreWebclient/gulp-tasks/styles.js');
require('./modules/CoreWebclient/gulp-tasks/tests.js');