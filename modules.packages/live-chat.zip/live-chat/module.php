<?php
	use fruithost\ModuleInterface;
	
	class LiveChat extends ModuleInterface {
		public function init() {
			
		}
	}
?>