<?php
	use fruithost\ModuleInterface;
	
	class Statistics extends ModuleInterface {
		public function init() {
			
		}
	}
?>