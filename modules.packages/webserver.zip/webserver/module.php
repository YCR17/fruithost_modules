<?php
	use fruithost\ModuleInterface;
	
	class WebServer extends ModuleInterface {
		public function init() {
			
		}
	}
?>